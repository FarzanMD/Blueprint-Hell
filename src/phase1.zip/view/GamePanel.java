package view;

import controller.*;
import model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class GamePanel extends JPanel {
    private final GameModel model;
    private final WireController wireController;
    private final PacketManager packetManager;
    private final LevelManager levelManager;
    private boolean isRunning = false;
    private Timer gameTimer;
    private final ShopManager shopManager;


    public void pauseGame() {
        if (gameTimer != null) {
            gameTimer.stop();
            MusicPlayer.getInstance().stop();
        }
    }

    public void resumeGame() {
        if (gameTimer != null) {
            gameTimer.start();
            MusicPlayer.getInstance().play();
        }
    }


    public GamePanel() {
        MusicPlayer.getInstance().play();

        setBackground(Color.WHITE);
        model = new GameModel();


        levelManager = new LevelManager(model);

        wireController = new WireController(levelManager);
        model.setWireController(wireController);

        try {
            levelManager.loadLevelFromFile("src/save.json");
        } catch (Exception ex) {
            ex.printStackTrace();
            // optional: show an error dialog
        }



        packetManager = new PacketManager(model.getCoinManager(),model);

        setFocusable(true);
        requestFocusInWindow();

        MouseController mouseController = new MouseController(model, wireController);
        addMouseListener(mouseController);
        addMouseMotionListener(mouseController);


        shopManager = new ShopManager(model.getCoinManager());

        // Spacebar toggles run/pause
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (allSystemsAreValid()) {
                        isRunning = !isRunning;
                        System.out.println("System is now " + (isRunning ? "RUNNING" : "PAUSED"));
                    } else {
                        System.out.println("Cannot start — not all systems are valid!");
                    }
                }
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_S) {
                    pauseGame(); // you should define this

                    new ShopWindow(
                            (JFrame) SwingUtilities.getWindowAncestor(GamePanel.this),
                            () -> model.getCoinManager().getCoins(), // 👈 clean coin supplier
                            e1 -> shopManager.tryBuyAtar(),
                            e2 -> shopManager.tryBuyAiryaman(),
                            e3 -> shopManager.tryBuyAnahita(packetManager)
                    );

                    resumeGame(); // resumes after shop closes
                }
            }
        });
        setFocusable(true);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    pauseGame();
                    int result = JOptionPane.showConfirmDialog(
                            GamePanel.this,
                            "Are you sure you want to exit?",
                            "Exit Confirmation",
                            JOptionPane.YES_NO_OPTION
                    );
                    if (result == JOptionPane.YES_OPTION) {
                        try {
                            // Save the game
                            levelManager.saveStateToFile("src/save.json");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        System.exit(0);
                    } else {
                        resumeGame();
                    }
                }
            }
        });



        gameTimer = new Timer(16, e -> {
            shopManager.update();
            if (isRunning) {
                packetManager.update(0.01f, model.getSystems(), wireController.getWires(), shopManager);
            }
            repaint();
        });
        gameTimer.start();

        // Packet spawning from start node (only while running)
        new Timer(2000, e -> {
            if (!isRunning) return;
            List<SystemNode> systems = model.getSystems();
            if (systems.isEmpty()) return;

            SystemNode start = systems.get(0);
            Wire wire = start.findNextAvailableWire(wireController.getWires());
            if (wire != null) {
                packetManager.spawnPacket(Packet.Shape.TRIANGLE, wire);
            }
        }).start();


    }
    public GamePanel(String path) {
        MusicPlayer.getInstance().play();


        setBackground(Color.WHITE);
        model = new GameModel(path);


        levelManager = new LevelManager(model);

        wireController = new WireController(levelManager);
        model.setWireController(wireController);

        try {
            levelManager.loadLevelFromFile(path);
        } catch (Exception ex) {
            ex.printStackTrace();
            // optional: show an error dialog
        }



        packetManager = new PacketManager(model.getCoinManager(),model);


        setFocusable(true);
        requestFocusInWindow();

        MouseController mouseController = new MouseController(model, wireController);
        addMouseListener(mouseController);
        addMouseMotionListener(mouseController);


        shopManager = new ShopManager(model.getCoinManager());

        // Spacebar toggles run/pause
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    if (allSystemsAreValid()) {
                        isRunning = !isRunning;
                        System.out.println("System is now " + (isRunning ? "RUNNING" : "PAUSED"));
                    } else {
                        System.out.println("Cannot start — not all systems are valid!");
                    }
                }
            }
        });
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_S) {
                    pauseGame(); // you should define this

                    new ShopWindow(
                            (JFrame) SwingUtilities.getWindowAncestor(GamePanel.this),
                            () -> model.getCoinManager().getCoins(), // 👈 clean coin supplier
                            e1 -> shopManager.tryBuyAtar(),
                            e2 -> shopManager.tryBuyAiryaman(),
                            e3 -> shopManager.tryBuyAnahita(packetManager)
                    );

                    resumeGame(); // resumes after shop closes
                }
            }
        });
        setFocusable(true);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    pauseGame();
                    int result = JOptionPane.showConfirmDialog(
                            GamePanel.this,
                            "Are you sure you want to exit?",
                            "Exit Confirmation",
                            JOptionPane.YES_NO_OPTION
                    );
                    if (result == JOptionPane.YES_OPTION) {
                        try {
                            // Save the game
                            levelManager.saveStateToFile("src/save.json");
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        System.exit(0);
                    } else {
                        resumeGame();
                    }
                }
            }
        });



        gameTimer = new Timer(16, e -> {
            shopManager.update();
            if (isRunning) {
                packetManager.update(0.01f, model.getSystems(), wireController.getWires(), shopManager);
            }
            repaint();
        });
        gameTimer.start();

        // Packet spawning from start node (only while running)
        new Timer(2000, e -> {
            if (!isRunning) return;
            List<SystemNode> systems = model.getSystems();
            if (systems.isEmpty()) return;

            SystemNode start = model.getStartNode();
            Wire wire = start.findNextAvailableWire(wireController.getWires());
            if (wire != null) {
                packetManager.spawnPacket(Packet.Shape.TRIANGLE, wire);
            }
        }).start();


    }

    private boolean allSystemsAreValid() {
        List<Wire> wires = wireController.getWires();
        for (SystemNode node : model.getSystems()) {
            if (!node.isFullyConnected(wires)) return false;
        }
        return true;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        List<Wire> wires = wireController.getWires();

        for (SystemNode node : model.getSystems()) {
            node.draw((Graphics2D) g, wires);
        }

        wireController.draw((Graphics2D) g);
        packetManager.draw((Graphics2D) g);

        // Optional debug display
        g.setColor(Color.BLACK);
        g.drawString("Status: " + (isRunning ? "RUNNING" : "PAUSED"), 10, 20);

        //g.setColor(Color.BLACK);
        g.setFont(new Font("Noto Emoji", Font.BOLD, 16));
        g.drawString("\uD83E\uDE99"+":" + model.getCoinManager().getCoins(), 10, 40);

        if (shopManager.isAtarActive()) {
            g.setColor(Color.ORANGE);
            g.setFont(new Font("Ariel", Font.BOLD , 16));
            g.drawString("O' Atar active", 20, 60);
        }
        if (shopManager.isAiryamanActive()) {
            g.setColor(Color.CYAN);
            g.setFont(new Font("Ariel", Font.BOLD , 16));
            g.drawString("O' Airyaman active", 20, 80);
        }

        int used = wireController.getTotalWireLength();
        int max = wireController.getMAX_TOTAL_LENGTH();
        g.setColor(Color.BLACK);
        g.setFont(new Font("Ariel", Font.BOLD , 16));
        g.drawString("Wire Length: " + used + " / " + max, 120, 20);



    }

}
