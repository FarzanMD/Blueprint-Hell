import view.MenuFrame;

public class  Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new MenuFrame();
        });
    }
}

